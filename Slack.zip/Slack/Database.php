<?php
//CREATE CONNECTION
 $connect = mysqli_connect("localhost","root","root");
 //CHECK CONNECTION
 if (!$connect) {
 	die("connection failed" . mysqli_connect_error());
 } 
 //CREATE DATABASE
 $_create = mysqli_query($connect,"create database if not exists slack");
 if($_create) {echo "Database created successfully";}
 else {
 	echo "Error creating database" . mysqli_error($connect);
 }








  ?>